#!/bin/bash

m=$(umask)
echo $m
if (( ($m & 6600) != 0 )); then
	echo "umask is set incorrectly. Please fix and then re-run."
exit 1
fi

touch /tmp/itran

