#!/bin/bash
cp /tmp/httpd.conf /etc/httpd/conf/httpd.conf
cp /tmp/index.html /root/index.html
